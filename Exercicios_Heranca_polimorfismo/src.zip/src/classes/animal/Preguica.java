package classes.animal;

public class Preguica extends Animal {

    @Override
    public String emitirSom() {
        return "hurrrrrr";
    }

    @Override
    public String mover() {
        return "hurrrr hurr";
    }
}
