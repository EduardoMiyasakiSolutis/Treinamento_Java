package classes.animal;

public class Cavalo extends Animal {

    @Override
    public String emitirSom() {
        return "Pocotó Pocotó";
    }

    @Override
    public String mover() {
        return " poct poct pocóto";
    }
}
