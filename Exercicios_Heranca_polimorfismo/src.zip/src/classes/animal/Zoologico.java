package classes.animal;

public class Zoologico {

   public Animal[] animais = new Animal[10];

}
