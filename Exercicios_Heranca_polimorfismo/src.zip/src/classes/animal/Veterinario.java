package classes.animal;

public class Veterinario {


    public void examinar(Animal animal){
        System.out.println("Examinando animal");
        System.out.println(animal.emitirSom());
    }
}
